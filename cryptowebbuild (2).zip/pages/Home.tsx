import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { GoogleGenAI } from "@google/genai";
import SEO from '../components/SEO';

const Home: React.FC = () => {
  const [text, setText] = useState('');
  const [generatedImage, setGeneratedImage] = useState<string | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const phrases = [
    'Viral Meme Coin Sites.',
    'Secure Token Presales.',
    'Fast E-commerce Stores.',
    'SEO-Ready Brand Sites.'
  ];
  
  const testimonials = [
    {
      name: "Alex R.",
      role: "Founder",
      company: "Solana Token Launch",
      quote: "Sagor delivered our presale page in 3 days. The load speed was instant and we hit our hard cap in 12 hours. Best dev we've hired."
    },
    {
      name: "Sarah J.",
      role: "CEO",
      company: "ModernShop E-com",
      quote: "The static site architecture changed everything. Our bounce rate dropped by 40% immediately. Highly recommended for performance."
    },
    {
      name: "Mike T.",
      role: "Lead Dev",
      company: "DeFi Dashboard Protocol",
      quote: "Clean code, great communication, and he actually understands Web3 context. The wallet integration was flawless."
    }
  ];
  
  useEffect(() => {
    let phraseIndex = 0;
    let charIndex = 0;
    let isDeleting = false;
    let timer: ReturnType<typeof setTimeout>;

    const type = () => {
      const current = phrases[phraseIndex % phrases.length];
      if (!isDeleting) {
        setText(current.slice(0, charIndex + 1));
        charIndex++;
        if (charIndex === current.length) {
          isDeleting = true;
          timer = setTimeout(type, 2000);
        } else {
          timer = setTimeout(type, 80);
        }
      } else {
        setText(current.slice(0, charIndex - 1));
        charIndex--;
        if (charIndex === 0) {
          isDeleting = false;
          phraseIndex++;
          timer = setTimeout(type, 300);
        } else {
          timer = setTimeout(type, 50);
        }
      }
    };
    timer = setTimeout(type, 500);
    return () => clearTimeout(timer);
  }, []);

  const generateImage = async () => {
    setIsGenerating(true);
    setError(null);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash-image',
        contents: [
          {
            parts: [
              {
                text: 'Abstract digital art background combining blockchain network nodes and web development code syntax in a cosmic style. Use deep purple, cyan, and blue neon lighting against a dark void. Minimalist, futuristic, high quality, 4k resolution.',
              },
            ],
          },
        ],
      });

      if (response.candidates?.[0]?.content?.parts) {
        let imageFound = false;
        for (const part of response.candidates[0].content.parts) {
          if (part.inlineData && part.inlineData.data) {
            setGeneratedImage(`data:image/png;base64,${part.inlineData.data}`);
            imageFound = true;
            break;
          }
        }
        if (!imageFound) {
            setError("The model generated text instead of an image. Please try again.");
        }
      } else {
        setError("No content returned from the model.");
      }
    } catch (err: any) {
      console.error("Failed to generate image", err);
      setError("Failed to generate image. Please check your connection and try again.");
    } finally {
      setIsGenerating(false);
    }
  };

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "ProfessionalService",
    "name": "CryptoWebBuild",
    "image": "https://cryptowebbuild.com/hero-avatar.webp",
    "url": "https://cryptowebbuild.com",
    "telephone": "",
    "priceRange": "$$-$$$",
    "address": {
      "@type": "PostalAddress",
      "addressCountry": "Remote"
    },
    "description": "Professional Website Developer specialized in Crypto, Web3, and E-commerce websites.",
    "founder": {
      "@type": "Person",
      "name": "Sagor Ahamed"
    },
    "sameAs": [
      "https://x.com/WebBuildDev",
      "https://t.me/CryptoWebBuild",
      "https://github.com/cryptowebbuild"
    ]
  };

  return (
    <div className="space-y-40 pb-20 overflow-hidden">
      <SEO 
        title="Professional Website Developer for Crypto & Web3 | Sagor Ahamed"
        description="Hire a professional developer for fast, secure Crypto, Web3, and Meme Coin websites. Expert in SEO-first landing pages and e-commerce growth."
      />
      <script type="application/ld+json">
        {JSON.stringify(jsonLd)}
      </script>
      
      {/* --- Hero Section --- */}
      <section className="relative pt-32 pb-20 px-6 min-h-[90vh] flex items-center justify-center text-center">
        
        {/* Glow Effects (Adaptive) */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-purple-300/30 dark:bg-purple-900/30 blur-[120px] rounded-full pointer-events-none mix-blend-multiply dark:mix-blend-normal" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[400px] h-[400px] bg-cyan-300/20 dark:bg-cyan-900/20 blur-[80px] rounded-full animate-pulse-slow pointer-events-none mix-blend-multiply dark:mix-blend-normal" />

        <div className="relative z-10 max-w-5xl mx-auto">
          
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-surface border border-white/10 backdrop-blur-md mb-8 animate-float shadow-sm hover:border-purple-300 dark:hover:border-purple-700 transition-colors">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500"></span>
            </span>
            <span className="text-sm font-medium text-text-muted">Speed • Security • Growth</span>
          </div>

          <h1 className="font-display text-5xl md:text-7xl font-bold tracking-tight mb-8 leading-[1.1] animate-slide-up">
            <span className="block text-text-main drop-shadow-sm">Launch High-Performance</span>
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-600 via-cyan-600 to-purple-600 bg-[length:200%_auto] animate-shimmer">
              Crypto & Commerce
            </span>
          </h1>

          <div className="h-10 mb-10 text-2xl md:text-3xl text-text-muted font-light animate-slide-up" style={{ animationDelay: '0.2s' }}>
            I build <span className="text-text-main font-medium">{text}</span>
            <span className="animate-pulse text-cyan-600">_</span>
          </div>

          <p className="text-lg md:text-xl text-text-muted max-w-2xl mx-auto mb-12 leading-relaxed animate-slide-up" style={{ animationDelay: '0.4s' }}>
            Turn traffic into holders and customers. I build secure, SEO-first websites tailored for <strong>high-stakes token launches</strong> and <strong>conversion-driven e-commerce</strong>. Fast, scalable, and deploy-ready.
          </p>

          <div className="flex flex-col sm:flex-row gap-6 justify-center items-center animate-slide-up" style={{ animationDelay: '0.6s' }}>
            <Link 
              to="/contact" 
              className="group relative px-8 py-4 bg-slate-900 dark:bg-white text-white dark:text-slate-900 font-bold text-lg rounded-xl overflow-hidden transition-all hover:scale-105 shadow-xl shadow-purple-200 dark:shadow-purple-900/50"
            >
              <div className="absolute inset-0 bg-gradient-to-r from-purple-600 to-cyan-600 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
              <span className="relative z-10 transition-colors group-hover:text-white">Get a Quote</span>
            </Link>
            
            <Link 
              to="/services" 
              className="px-8 py-4 text-text-main font-medium rounded-xl border border-slate-300 dark:border-slate-700 hover:bg-surface-highlight transition-all backdrop-blur-sm"
            >
              View Services
            </Link>
          </div>
        </div>
      </section>

      {/* --- Services Preview --- */}
      <section className="container mx-auto px-6">
        <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-6">
          <div className="max-w-xl">
            <h2 className="font-display text-4xl md:text-5xl font-bold text-text-main mb-4">
              Services I Provide
            </h2>
            <p className="text-text-muted text-lg">
              Full-stack and static-first websites tailored for performance and growth.
            </p>
          </div>
          <Link to="/services" className="text-cyan-600 font-bold hover:text-cyan-800 transition-colors flex items-center gap-2 group">
            All Services <span className="group-hover:translate-x-1 transition-transform">→</span>
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          
          {/* Service 1 - Crypto */}
          <div className="glass-panel p-8 rounded-3xl hover:border-purple-300 transition-all duration-500 group relative overflow-hidden bg-surface">
            <div className="absolute inset-0 bg-gradient-to-br from-purple-500/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
            <div className="relative z-10">
              {/* Premium Icon */}
              <div className="w-16 h-16 mb-6 rounded-2xl bg-gradient-to-br from-purple-500/10 to-purple-500/20 border border-purple-500/20 flex items-center justify-center group-hover:scale-110 transition-transform duration-500 shadow-sm group-hover:shadow-md">
                 <svg className="w-8 h-8 text-purple-600 dark:text-purple-400" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M6 3L2 9L12 21L22 9L18 3H6Z" />
                    <path d="M11 3L8 9L12 21L16 9L13 3" />
                 </svg>
              </div>
              <h3 className="font-display text-xl font-bold text-text-main mb-2">Crypto & Web3</h3>
              <p className="text-text-muted text-sm">
                Token landing pages, tokenomics, presale flows, contract links and on-page SEO tailored for token launches.
              </p>
            </div>
          </div>

          {/* Service 2 - E-commerce */}
          <div className="glass-panel p-8 rounded-3xl hover:border-cyan-300 transition-all duration-500 group relative overflow-hidden bg-surface">
            <div className="absolute inset-0 bg-gradient-to-br from-cyan-500/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
            <div className="relative z-10">
              {/* Premium Icon */}
              <div className="w-16 h-16 mb-6 rounded-2xl bg-gradient-to-br from-cyan-500/10 to-cyan-500/20 border border-cyan-500/20 flex items-center justify-center group-hover:scale-110 transition-transform duration-500 shadow-sm group-hover:shadow-md">
                 <svg className="w-8 h-8 text-cyan-600 dark:text-cyan-400" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
                    <circle cx="9" cy="21" r="1" />
                    <circle cx="20" cy="21" r="1" />
                    <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6" />
                 </svg>
              </div>
              <h3 className="font-display text-xl font-bold text-text-main mb-2">E-Commerce</h3>
              <p className="text-text-muted text-sm">
                Product pages, JavaScript carts and secure payment gateways — optimized for speed, UX and SEO.
              </p>
            </div>
          </div>

           {/* Service 3 - Business */}
          <div className="glass-panel p-8 rounded-3xl hover:border-blue-300 transition-all duration-500 group relative overflow-hidden bg-surface">
            <div className="absolute inset-0 bg-gradient-to-br from-blue-500/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
            <div className="relative z-10">
              {/* Premium Icon */}
               <div className="w-16 h-16 mb-6 rounded-2xl bg-gradient-to-br from-blue-500/10 to-blue-500/20 border border-blue-500/20 flex items-center justify-center group-hover:scale-110 transition-transform duration-500 shadow-sm group-hover:shadow-md">
                 <svg className="w-8 h-8 text-blue-600 dark:text-blue-400" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M3 21h18" />
                    <path d="M5 21V7" />
                    <path d="M9 21V11" />
                    <path d="M13 21V3" />
                    <path d="M17 21v6" />
                 </svg>
              </div>
              <h3 className="font-display text-xl font-bold text-text-main mb-2">Business Sites</h3>
              <p className="text-text-muted text-sm">
                Responsive websites for local businesses and startups with SEO-focused content and clear CTAs.
              </p>
            </div>
          </div>

           {/* Service 4 - Blogs */}
          <div className="glass-panel p-8 rounded-3xl hover:border-pink-300 transition-all duration-500 group relative overflow-hidden bg-surface">
            <div className="absolute inset-0 bg-gradient-to-br from-pink-500/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
            <div className="relative z-10">
              {/* Premium Icon */}
               <div className="w-16 h-16 mb-6 rounded-2xl bg-gradient-to-br from-pink-500/10 to-pink-500/20 border border-pink-500/20 flex items-center justify-center group-hover:scale-110 transition-transform duration-500 shadow-sm group-hover:shadow-md">
                 <svg className="w-8 h-8 text-pink-600 dark:text-pink-400" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M12 19l7-7 3 3-7 7-3-3z" />
                    <path d="M18 13l-1.5-7.5L2 2l3.5 14.5L13 18l5-5z" />
                    <path d="M2 2l7.586 7.586" />
                    <circle cx="11" cy="11" r="2" />
                 </svg>
              </div>
              <h3 className="font-display text-xl font-bold text-text-main mb-2">Blogs & Portfolios</h3>
              <p className="text-text-muted text-sm">
                Fast static blogs and portfolios for personal branding, case studies and organic traffic growth.
              </p>
            </div>
          </div>

        </div>
      </section>

      {/* --- Why Choose Me --- */}
      <section className="container mx-auto px-6">
        <div className="bg-gradient-to-b from-surface to-void border border-white/10 rounded-[40px] p-8 md:p-20 relative overflow-hidden shadow-lg shadow-purple-500/10">
          <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-purple-500/10 blur-[150px] rounded-full" />
          
          <div className="relative z-10 text-center max-w-3xl mx-auto mb-16">
            <h2 className="font-display text-3xl md:text-5xl font-bold text-text-main mb-6">
              Why Choose Me
            </h2>
            <p className="text-text-muted text-lg">
              I deliver high-performance digital assets that drive growth.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 relative z-10">
            {[
              { title: 'Global Performance', desc: 'Speed-first static/CDN architecture for global availability.' },
              { title: 'SEO Optimized', desc: 'SEO-first templates, JSON-LD, and sitemaps for Google & AI.' },
              { title: 'Measurable Growth', desc: 'Conversion-focused CTAs and analytics for real results.' }
            ].map((item, i) => (
              <div key={i} className="text-center group p-6 rounded-2xl hover:bg-surface hover:shadow-md transition-all border border-transparent hover:border-white/10">
                 <div className="w-12 h-12 mx-auto bg-surface rounded-full flex items-center justify-center text-text-main font-display font-bold text-lg mb-4 border border-white/20 group-hover:border-cyan-400 group-hover:text-cyan-600 transition-all shadow-md">
                  {i + 1}
                </div>
                <h3 className="text-xl font-bold text-text-main mb-3">{item.title}</h3>
                <p className="text-text-muted text-sm">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* --- Testimonials Section --- */}
      <section className="container mx-auto px-6 mb-32">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="font-display text-4xl md:text-5xl font-bold text-text-main mb-6">
            Trusted by Builders
          </h2>
          <p className="text-text-muted text-lg">
            Here's what founders and teams say about working with me.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((t, i) => (
            <div key={i} className="glass-panel p-8 rounded-3xl bg-surface hover:border-purple-300 dark:hover:border-purple-700 transition-all duration-300 relative">
              {/* Quote Icon */}
              <div className="text-purple-500 mb-6">
                <svg width="40" height="40" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M14.017 21L14.017 18C14.017 16.8954 14.9124 16 16.017 16H19.017C19.5693 16 20.017 15.5523 20.017 15V9C20.017 8.44772 19.5693 8 19.017 8H15.017C14.4647 8 14.017 8.44772 14.017 9V11C14.017 11.5523 13.5693 12 13.017 12H12.017V5H22.017V15C22.017 18.3137 19.3307 21 16.017 21H14.017ZM5.0166 21L5.0166 18C5.0166 16.8954 5.91203 16 7.0166 16H10.0166C10.5689 16 11.0166 15.5523 11.0166 15V9C11.0166 8.44772 10.5689 8 10.0166 8H6.0166C5.46432 8 5.0166 8.44772 5.0166 9V11C5.0166 11.5523 4.56889 12 4.0166 12H3.0166V5H13.0166V15C13.0166 18.3137 10.3303 21 7.0166 21H5.0166Z" />
                </svg>
              </div>
              <p className="text-text-main text-lg mb-6 leading-relaxed">"{t.quote}"</p>
              <div className="flex items-center gap-4">
                 <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-500 to-cyan-500 flex items-center justify-center text-white font-bold font-display text-sm">
                    {t.name.charAt(0)}
                 </div>
                 <div>
                    <div className="font-bold text-text-main">{t.name}</div>
                    <div className="text-sm text-text-muted">{t.role}, {t.company}</div>
                 </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* --- AI Image Gen Section --- */}
      <section className="container mx-auto px-6 mb-32">
        <div className="relative rounded-[32px] overflow-hidden min-h-[500px] border border-white/10 flex items-center justify-center bg-surface transition-all duration-500">
          
          {/* Background Image Layer */}
          {generatedImage ? (
            <div 
              className="absolute inset-0 bg-cover bg-center transition-opacity duration-700 animate-fade-in"
              style={{ backgroundImage: `url(${generatedImage})` }}
            />
          ) : (
            <div className="absolute inset-0 bg-gradient-to-br from-slate-900 via-purple-900 to-slate-950 opacity-100" />
          )}
          
          {/* Overlay */}
          <div className="absolute inset-0 bg-black/40 backdrop-blur-[2px]" />

          <div className="relative z-10 text-center max-w-2xl px-6">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 backdrop-blur-md border border-white/20 text-white text-xs font-bold uppercase tracking-widest mb-6">
              <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse"></span>
              Live Demo
            </div>
            <h2 className="font-display text-4xl md:text-5xl font-bold text-white mb-6">
              AI-Generated <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-purple-400">Visuals</span>
            </h2>
            <p className="text-white/80 text-lg mb-8 leading-relaxed">
              I integrate cutting-edge Generative AI to create unique, royalty-free assets for your projects on the fly. 
              Try generating a unique abstract background for this section right now.
            </p>
            
            <button 
              onClick={generateImage}
              disabled={isGenerating}
              className="group relative inline-flex items-center justify-center px-8 py-4 font-bold text-white transition-all duration-200 bg-white/10 border border-white/20 rounded-xl hover:bg-white/20 focus:outline-none disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isGenerating ? (
                <span className="flex items-center gap-2">
                  <svg className="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  Dreaming...
                </span>
              ) : (
                <span className="flex items-center gap-2">
                  <svg className="w-5 h-5 text-purple-400 group-hover:scale-110 transition-transform" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                     <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19.428 15.428a2 2 0 00-1.022-.547l-2.384-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z" />
                  </svg>
                  Generate Background
                </span>
              )}
            </button>
            
            {error && (
              <div className="mt-4 p-4 bg-red-500/20 border border-red-500/50 rounded-xl text-white text-sm animate-fade-in">
                {error}
              </div>
            )}
          </div>
        </div>
      </section>

      {/* --- CTA Section --- */}
      <section className="container mx-auto px-6">
        <div className="relative rounded-[40px] overflow-hidden p-12 md:p-24 text-center border border-slate-200 dark:border-slate-800 group bg-slate-900 shadow-2xl shadow-slate-300 dark:shadow-none">
          <div className="absolute inset-0 bg-gradient-to-r from-purple-900/40 to-blue-900/40 opacity-50 group-hover:opacity-70 transition-opacity duration-500" />
          <div className="absolute inset-0 backdrop-blur-3xl" />
          
          <div className="relative z-10">
            <h2 className="font-display text-4xl md:text-6xl font-bold text-white mb-8">
              Ready to build?
            </h2>
            <p className="text-slate-200 mb-10 text-lg">
              Book a free consultation and I’ll share a roadmap tailored to your project.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Link 
                to="/contact" 
                className="inline-flex items-center justify-center px-10 py-5 bg-white text-slate-900 text-lg font-bold rounded-2xl hover:scale-105 transition-transform shadow-lg shadow-white/10"
                >
                Get a Free Consultation
                </Link>
                <Link 
                to="/projects" 
                className="inline-flex items-center justify-center px-10 py-5 bg-white/10 border border-white/20 text-white text-lg font-bold rounded-2xl hover:bg-white/20 transition-colors"
                >
                See Portfolio
                </Link>
            </div>
          </div>
        </div>
      </section>

    </div>
  );
};

export default Home;