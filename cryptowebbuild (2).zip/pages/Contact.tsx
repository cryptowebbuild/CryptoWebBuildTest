import React from 'react';
import SEO from '../components/SEO';

const Contact: React.FC = () => {
  return (
    <div className="container mx-auto px-6 pt-32 pb-20">
      <SEO 
        title="Contact Sagor Ahamed | Get a Free Project Quote"
        description="Discuss your crypto, web3, or business project. Get a fast, accurate quote and timeline for your custom website build."
      />
      <div className="max-w-3xl mx-auto">
        <div className="text-center mb-12 animate-slide-up">
          <div className="inline-block px-4 py-1.5 mb-4 rounded-full bg-white border border-slate-200 text-cyan-600 text-sm font-bold tracking-wider uppercase shadow-sm">
            Open for Work
          </div>
          <h1 className="font-display text-5xl font-bold text-slate-900 mb-4">Let's Talk</h1>
          <p className="text-slate-600 text-lg">Tell me about your project — I usually reply within a few hours.</p>
        </div>

        <div className="glass-panel p-8 md:p-12 rounded-3xl shadow-xl shadow-slate-200/50 border-t border-purple-200 animate-slide-up bg-white" style={{ animationDelay: '0.2s' }}>
          <form action="https://api.web3forms.com/submit" method="POST" className="space-y-8">
            <input type="hidden" name="access_key" value="75fafb45-1a1e-41ee-86b7-4637bbd35224" />
            <input type="hidden" name="_redirect" value="https://cryptowebbuild.com/thank-you" />

            <div className="grid md:grid-cols-2 gap-8">
                <div className="space-y-2">
                    <label htmlFor="name" className="block text-sm font-bold text-slate-500 uppercase tracking-wide">Your Name</label>
                    <input 
                        id="name" 
                        name="name" 
                        type="text" 
                        required 
                        placeholder="John Doe"
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl px-5 py-4 text-slate-900 placeholder-slate-400 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 transition-all hover:border-slate-300"
                    />
                </div>

                <div className="space-y-2">
                    <label htmlFor="email" className="block text-sm font-bold text-slate-500 uppercase tracking-wide">Your Email</label>
                    <input 
                        id="email" 
                        name="email" 
                        type="email" 
                        required 
                        placeholder="you@example.com"
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl px-5 py-4 text-slate-900 placeholder-slate-400 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 transition-all hover:border-slate-300"
                    />
                </div>
            </div>

            <div className="space-y-2">
              <label htmlFor="category" className="block text-sm font-bold text-slate-500 uppercase tracking-wide">Project Category</label>
              <select 
                id="category" 
                name="category" 
                required
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-5 py-4 text-slate-900 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 transition-all appearance-none cursor-pointer hover:border-slate-300"
              >
                <option value="" disabled selected className="text-slate-400">Select a project type</option>
                <option className="text-slate-900">Web3 & Crypto Website</option>
                <option className="text-slate-900">Meme Coin Landing Page</option>
                <option className="text-slate-900">Token Presale Website</option>
                <option className="text-slate-900">Business/Company Website</option>
                <option className="text-slate-900">E-commerce Store</option>
                <option className="text-slate-900">Portfolio / Blog</option>
                <option className="text-slate-900">Custom Web Project</option>
              </select>
            </div>

            <div className="space-y-2">
              <label htmlFor="budget" className="block text-sm font-bold text-slate-500 uppercase tracking-wide">Project Budget</label>
              <select 
                id="budget" 
                name="budget" 
                required
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-5 py-4 text-slate-900 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 transition-all appearance-none cursor-pointer hover:border-slate-300"
              >
                <option value="" disabled selected className="text-slate-400">Select your budget</option>
                <option className="text-slate-900">$50 – $150 (Small fixes)</option>
                <option className="text-slate-900">$150 – $300 (Starter)</option>
                <option className="text-slate-900">$300 – $600 (Business)</option>
                <option className="text-slate-900">$600 – $1200 (Crypto/Web3)</option>
                <option className="text-slate-900">$1200+ (Custom DApp)</option>
              </select>
            </div>

            <div className="space-y-2">
              <label htmlFor="message" className="block text-sm font-bold text-slate-500 uppercase tracking-wide">Your Message</label>
              <textarea 
                id="message" 
                name="message" 
                rows={5}
                required 
                placeholder="Describe your project, timeline, and any specific requirements..."
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-5 py-4 text-slate-900 placeholder-slate-400 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 transition-all resize-none hover:border-slate-300"
              ></textarea>
            </div>

            <button 
              type="submit" 
              className="w-full py-4 bg-gradient-to-r from-purple-600 to-cyan-600 rounded-xl text-white font-bold text-lg shadow-lg shadow-purple-200 hover:shadow-purple-300 hover:scale-[1.01] transition-all"
            >
              Send Message
            </button>
          </form>
        </div>

        <div className="mt-10 text-center text-slate-500 text-sm">
          Prefer direct message? Reach me on <a href="https://t.me/CryptoWebBuild" className="text-cyan-600 hover:text-cyan-800 transition-colors underline decoration-dotted underline-offset-4">Telegram</a> or <a href="mailto:hello@cryptowebbuild.com" className="text-cyan-600 hover:text-cyan-800 transition-colors underline decoration-dotted underline-offset-4">Email</a>.
        </div>
      </div>
    </div>
  );
};

export default Contact;