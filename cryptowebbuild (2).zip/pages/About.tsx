import React from 'react';
import { Link } from 'react-router-dom';
import SEO from '../components/SEO';

const About: React.FC = () => {
  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "ProfilePage",
    "mainEntity": {
      "@type": "Person",
      "name": "Sagor Ahamed",
      "alternateName": "CryptoWebBuild",
      "jobTitle": "Senior Web Developer",
      "image": "https://cryptowebbuild.com/sagor-ahamed.webp",
      "description": "Full-stack developer specialized in high-performance Web3 interfaces, e-commerce, and modern web architecture.",
      "sameAs": [
        "https://x.com/WebBuildDev",
        "https://t.me/CryptoWebBuild",
        "https://github.com/cryptowebbuild"
      ]
    }
  };

  const techStack = [
    { name: 'React & Next.js', icon: '⚛️', desc: 'Component architecture' },
    { name: 'TypeScript', icon: 'ts', desc: 'Type-safe logic' },
    { name: 'Tailwind CSS', icon: '🎨', desc: 'Rapid UI design' },
    { name: 'Node.js', icon: '🟢', desc: 'Backend runtime' },
    { name: 'Web3 Integration', icon: '🔗', desc: 'Wagmi / Ethers.js' },
    { name: 'Cloudflare', icon: '☁️', desc: 'Edge deployment' }
  ];

  return (
    <div className="container mx-auto px-6 pt-32 pb-20">
      <SEO 
        title="About Sagor Ahamed | Senior Web3 & Frontend Developer"
        description="Meet Sagor Ahamed, a professional web developer building the future of the decentralized web. Expert in React, Crypto interfaces, and high-speed SEO."
      />
      <script type="application/ld+json">
        {JSON.stringify(jsonLd)}
      </script>

      {/* Hero Bio Section */}
      <div className="relative mb-32">
        <div className="glass-panel rounded-[3rem] p-8 md:p-16 border-t border-purple-200 dark:border-purple-900 shadow-2xl shadow-purple-500/10 bg-surface overflow-hidden">
            
            {/* Background Glows */}
            <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-purple-500/10 blur-[100px] rounded-full pointer-events-none"></div>
            <div className="absolute bottom-0 left-0 w-[400px] h-[400px] bg-cyan-500/10 blur-[100px] rounded-full pointer-events-none"></div>

            <div className="relative z-10 flex flex-col md:flex-row items-center gap-12 md:gap-20">
                
                {/* Image Column */}
                <div className="shrink-0 relative group">
                    <div className="absolute inset-0 bg-gradient-to-tr from-purple-600 to-cyan-600 rounded-[2rem] blur opacity-30 group-hover:opacity-50 transition-opacity duration-500"></div>
                    <div className="relative w-64 h-64 md:w-80 md:h-80 rounded-[2rem] overflow-hidden border-2 border-white/10 shadow-2xl">
                        <img 
                            src="/sagor-ahamed.webp" 
                            alt="Sagor Ahamed - Web Developer" 
                            className="w-full h-full object-cover transform transition-transform duration-700 group-hover:scale-105"
                            loading="lazy"
                            decoding="async"
                        />
                    </div>
                    
                    {/* Floating Badge */}
                    <div className="absolute -bottom-6 -right-6 glass-panel px-6 py-3 rounded-2xl border border-white/20 shadow-lg animate-float" style={{ animationDelay: '1s' }}>
                        <span className="text-sm font-bold text-text-main flex items-center gap-2">
                            <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
                            Open for Projects
                        </span>
                    </div>
                </div>

                {/* Text Column */}
                <div className="text-center md:text-left">
                    <div className="inline-block px-4 py-1.5 mb-6 rounded-full bg-purple-100 dark:bg-purple-900/30 border border-purple-200 dark:border-purple-800 text-purple-600 dark:text-purple-300 text-xs font-bold tracking-wider uppercase shadow-sm">
                        Senior Developer
                    </div>
                    <h1 className="font-display text-5xl md:text-6xl lg:text-7xl font-bold text-text-main mb-6 leading-tight">
                        Hi, I'm <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-600 to-cyan-600">Sagor.</span>
                    </h1>
                    <p className="text-xl md:text-2xl text-text-muted leading-relaxed mb-8 font-light">
                        I build the <strong className="text-text-main font-semibold">decentralized web</strong>. I turn complex crypto protocols and business ideas into pixel-perfect, high-performance digital experiences.
                    </p>
                    <div className="flex flex-col sm:flex-row gap-4 justify-center md:justify-start">
                         <a href="https://t.me/CryptoWebBuild" target="_blank" rel="noopener noreferrer" className="px-8 py-4 bg-slate-900 dark:bg-white text-white dark:text-slate-900 font-bold rounded-xl hover:scale-105 transition-transform shadow-lg">
                            Chat on Telegram
                        </a>
                        <Link to="/projects" className="px-8 py-4 bg-surface border border-slate-200 dark:border-slate-700 text-text-main font-bold rounded-xl hover:bg-surface-highlight transition-colors">
                            View Portfolio
                        </Link>
                    </div>
                </div>
            </div>
        </div>
      </div>

      {/* The Story / Philosophy */}
      <div className="grid md:grid-cols-2 gap-12 md:gap-24 mb-32 items-start">
        <div className="space-y-8">
            <h2 className="font-display text-3xl md:text-4xl font-bold text-text-main">
                More than just code. <br/>
                <span className="text-purple-500">I build assets.</span>
            </h2>
            <div className="prose prose-lg text-text-muted dark:prose-invert">
                <p>
                    In 2026, a website isn't just a digital brochure; it's a conversion engine. Whether you are launching a Solana token, dropping an NFT collection, or scaling an e-commerce brand, speed and trust are your currency.
                </p>
                <p>
                    I started my journey hacking together simple scripts and fell in love with the immediate impact of web development. Today, I specialize in the intersection of <strong>Design, Performance, and Web3</strong>.
                </p>
                <p>
                    I don't just "install themes." I architect solutions using modern tools like React, Next.js, and Tailwind CSS to ensure your site loads instantly anywhere on the planet.
                </p>
            </div>
            
            <div className="grid grid-cols-2 gap-6">
                <div className="p-6 bg-surface border border-white/10 rounded-2xl">
                    <div className="text-3xl font-bold text-cyan-500 mb-1">5+</div>
                    <div className="text-sm text-text-muted font-bold uppercase tracking-wider">Years Exp.</div>
                </div>
                <div className="p-6 bg-surface border border-white/10 rounded-2xl">
                    <div className="text-3xl font-bold text-purple-500 mb-1">100+</div>
                    <div className="text-sm text-text-muted font-bold uppercase tracking-wider">Projects</div>
                </div>
            </div>
        </div>

        {/* Tech Stack Grid */}
        <div>
            <h3 className="font-display text-2xl font-bold text-text-main mb-8">My Weapons of Choice</h3>
            <div className="grid grid-cols-2 gap-4">
                {techStack.map((tech, i) => (
                    <div key={i} className="group p-4 bg-surface border border-white/10 hover:border-purple-500/30 rounded-2xl transition-all hover:-translate-y-1 hover:shadow-lg">
                        <div className="flex items-center gap-3 mb-2">
                            <span className="text-2xl">{tech.icon === 'ts' ? (
                                <svg className="w-6 h-6 text-blue-600" viewBox="0 0 24 24" fill="currentColor"><path d="M1.125 0C0.502 0 0 0.502 0 1.125v21.75C0 23.498 0.502 24 1.125 24h21.75c0.623 0 1.125-0.502 1.125-1.125V1.125C24 0.502 23.498 0 22.875 0H1.125zM15.266 18.063h-3.328v-1.782h3.328v1.782zm-8.832 0H3.106v-7.149h5.188v1.782H4.888v1.781h1.547v1.782H4.888v1.804zm6.602-5.367H11.25v-1.782h3.328v1.782z"/></svg>
                            ) : tech.icon}</span>
                            <span className="font-bold text-text-main">{tech.name}</span>
                        </div>
                        <p className="text-xs text-text-muted font-medium uppercase tracking-wide">{tech.desc}</p>
                    </div>
                ))}
            </div>
            
            <div className="mt-8 p-6 bg-surface-highlight rounded-2xl border border-white/10">
                <h4 className="font-bold text-text-main mb-2">Philosophy</h4>
                <p className="text-sm text-text-muted italic">"A slow website is a broken website. I obsess over milliseconds so you don't lose customers."</p>
            </div>
        </div>
      </div>

      {/* Timeline / Journey */}
      <div className="max-w-3xl mx-auto mb-32">
        <h2 className="font-display text-3xl font-bold text-center text-text-main mb-12">The Journey</h2>
        <div className="relative border-l-2 border-slate-200 dark:border-slate-800 ml-6 space-y-12">
            
            <div className="relative pl-12">
                <div className="absolute -left-[9px] top-0 w-4 h-4 rounded-full bg-purple-500 border-4 border-void"></div>
                <div className="text-sm text-purple-600 font-bold mb-1">Present</div>
                <h3 className="text-xl font-bold text-text-main mb-2">Senior Freelance Developer</h3>
                <p className="text-text-muted">Specializing in high-stakes launches for Crypto projects and building headless e-commerce stores for modern brands.</p>
            </div>

            <div className="relative pl-12">
                <div className="absolute -left-[9px] top-0 w-4 h-4 rounded-full bg-slate-300 dark:bg-slate-700 border-4 border-void"></div>
                <div className="text-sm text-text-muted font-bold mb-1">2023 - 2024</div>
                <h3 className="text-xl font-bold text-text-main mb-2">Web3 Frontend Lead</h3>
                <p className="text-text-muted">Led frontend development for multiple DeFi protocols, ensuring secure wallet connections and real-time data visualization.</p>
            </div>

            <div className="relative pl-12">
                <div className="absolute -left-[9px] top-0 w-4 h-4 rounded-full bg-slate-300 dark:bg-slate-700 border-4 border-void"></div>
                <div className="text-sm text-text-muted font-bold mb-1">2021 - 2023</div>
                <h3 className="text-xl font-bold text-text-main mb-2">Full Stack Developer</h3>
                <p className="text-text-muted">Built custom MERN stack applications and WordPress solutions for agencies and small businesses.</p>
            </div>
        </div>
      </div>

      {/* CTA */}
      <div className="text-center max-w-2xl mx-auto">
        <h2 className="font-display text-4xl font-bold text-text-main mb-6">Let's build something epic.</h2>
        <p className="text-text-muted text-lg mb-8">
            I'm currently accepting new projects for Q4 2025. If you need a developer who cares about your business growth as much as the code, let's talk.
        </p>
        <Link to="/contact" className="inline-flex items-center justify-center px-10 py-5 bg-gradient-to-r from-purple-600 to-cyan-600 text-white font-bold rounded-2xl shadow-xl hover:scale-105 transition-transform">
            Start Your Project
        </Link>
      </div>

    </div>
  );
};

export default About;