import React from 'react';
import { Link } from 'react-router-dom';
import SEO from '../../components/SEO';

const TokenLaunch: React.FC = () => {
  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Article",
    "headline": "Case Study: Solana Presale Token Launch",
    "image": "https://cryptowebbuild.com/project-solana.jpg",
    "author": {
      "@type": "Organization",
      "name": "CryptoWebBuild"
    },
    "description": "How we built a high-converting Solana presale site with 0.8s load times and wallet integration using Cloudflare Pages."
  };

  return (
    <div className="container mx-auto px-6 pt-32 pb-20">
      <SEO 
        title="Case Study: TokenLaunch - Solana Presale Landing Page"
        description="How we built a high-converting Solana presale site with 0.8s load times and wallet integration using Cloudflare Pages."
      />
      <script type="application/ld+json">
        {JSON.stringify(jsonLd)}
      </script>
      <div className="max-w-4xl mx-auto animate-slide-up">
        <div className="inline-block px-3 py-1 mb-6 rounded-full bg-purple-100 dark:bg-purple-900/30 border border-purple-200 dark:border-purple-800 text-purple-600 dark:text-purple-300 text-xs font-bold uppercase tracking-wider shadow-sm">
          Case Study
        </div>
        <h1 className="font-display text-4xl md:text-5xl lg:text-6xl font-bold text-text-main mb-8 leading-tight">
          TokenLaunch — <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-500 to-cyan-500">Solana Presale</span>
        </h1>
        
        <div className="rounded-3xl overflow-hidden shadow-2xl border border-slate-200 dark:border-slate-800 mb-12">
            <img src="/project-solana.jpg" alt="Solana Token Launch Dashboard" className="w-full h-auto object-cover" />
        </div>

        <div className="grid md:grid-cols-3 gap-6 mb-16">
          <div className="glass-panel p-6 rounded-2xl bg-surface border-t border-purple-500/20">
            <h3 className="text-text-muted text-xs font-bold uppercase tracking-widest mb-2">Stack</h3>
            <p className="text-text-main font-bold text-lg">Static HTML, Cloudflare</p>
          </div>
          <div className="glass-panel p-6 rounded-2xl bg-surface border-t border-purple-500/20">
            <h3 className="text-text-muted text-xs font-bold uppercase tracking-widest mb-2">Focus</h3>
            <p className="text-text-main font-bold text-lg">Speed, Conversion</p>
          </div>
          <div className="glass-panel p-6 rounded-2xl bg-surface border-t border-purple-500/20">
            <h3 className="text-text-muted text-xs font-bold uppercase tracking-widest mb-2">Result</h3>
            <p className="text-green-500 font-bold text-lg">+62% Signups</p>
          </div>
        </div>

        <div className="prose prose-lg prose-slate dark:prose-invert max-w-none">
          <h2>The Challenge</h2>
          <p>Slow loading times on the previous site were killing presale conversions. Mobile performance was poor, leading to high bounce rates for traffic coming from Twitter and Telegram.</p>

          <h2>The Solution</h2>
          <p>We built a static-first landing page hosted on Cloudflare's global CDN. Key features included:</p>
          <ul>
            <li><strong>WalletConnect integration</strong> for seamless whitelist signups.</li>
            <li><strong>Live Solana price feed</strong> via lightweight API to keep users engaged.</li>
            <li><strong>Lazy-loading images</strong> and critical CSS inlining for instant paint.</li>
          </ul>

          <h2>The Outcome</h2>
          <p>Largest Contentful Paint (LCP) dropped to 0.8s globally. Presale signups increased by 62% in the first week compared to the previous dynamic WordPress site.</p>
        </div>

        <div className="mt-16 text-center pt-10 border-t border-white/10">
          <Link to="/projects" className="inline-flex items-center text-purple-600 hover:text-purple-400 font-bold transition-colors">
            <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path></svg>
            Back to Projects
          </Link>
        </div>
      </div>
    </div>
  );
};

export default TokenLaunch;