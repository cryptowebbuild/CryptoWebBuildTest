import React from 'react';
import { Link } from 'react-router-dom';
import SEO from '../../components/SEO';

const MemeCoinSite: React.FC = () => {
  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Article",
    "headline": "Case Study: Viral Meme Coin Launch Page",
    "image": "https://cryptowebbuild.com/project-memecoin.jpg",
    "author": {
      "@type": "Organization",
      "name": "CryptoWebBuild"
    },
    "description": "Analyzing a viral meme coin launch. How countdowns, social proof, and bold design drove a 34% conversion rate."
  };

  return (
    <div className="container mx-auto px-6 pt-32 pb-20">
      <SEO 
        title="Case Study: MemeCoinSite - Viral BNB Launch Page"
        description="Analyzing a viral meme coin launch. How countdowns, social proof, and bold design drove a 34% conversion rate."
      />
      <script type="application/ld+json">
        {JSON.stringify(jsonLd)}
      </script>
      <div className="max-w-4xl mx-auto animate-slide-up">
        <div className="inline-block px-3 py-1 mb-6 rounded-full bg-pink-100 dark:bg-pink-900/30 border border-pink-200 dark:border-pink-800 text-pink-600 dark:text-pink-300 text-xs font-bold uppercase tracking-wider shadow-sm">
          Case Study
        </div>
        <h1 className="font-display text-4xl md:text-5xl lg:text-6xl font-bold text-text-main mb-8 leading-tight">
          MemeCoinSite — <span className="text-transparent bg-clip-text bg-gradient-to-r from-pink-500 to-purple-500">BNB Launch</span>
        </h1>
        
        <div className="rounded-3xl overflow-hidden shadow-2xl border border-slate-200 dark:border-slate-800 mb-12">
            <img src="/project-memecoin.jpg" alt="Meme Coin Landing Page" className="w-full h-auto object-cover" />
        </div>

        <div className="grid md:grid-cols-3 gap-6 mb-16">
          <div className="glass-panel p-6 rounded-2xl bg-surface border-t border-pink-500/20">
            <h3 className="text-text-muted text-xs font-bold uppercase tracking-widest mb-2">Stack</h3>
            <p className="text-text-main font-bold text-lg">HTML, JS, Analytics</p>
          </div>
          <div className="glass-panel p-6 rounded-2xl bg-surface border-t border-pink-500/20">
            <h3 className="text-text-muted text-xs font-bold uppercase tracking-widest mb-2">Focus</h3>
            <p className="text-text-main font-bold text-lg">Viral, Urgency</p>
          </div>
          <div className="glass-panel p-6 rounded-2xl bg-surface border-t border-pink-500/20">
            <h3 className="text-text-muted text-xs font-bold uppercase tracking-widest mb-2">Result</h3>
            <p className="text-green-500 font-bold text-lg">34% Conversion</p>
          </div>
        </div>

        <div className="prose prose-lg prose-slate dark:prose-invert max-w-none prose-headings:font-display prose-headings:font-bold">
          <h2>Goal</h2>
          <p>Create a viral-ready landing page that captures presale interest and supports aggressive social campaigns on Twitter and Telegram.</p>

          <h2>Approach</h2>
          <ul>
            <li><strong>Bold visuals:</strong> High-contrast mascot branding to stand out in feeds.</li>
            <li><strong>Urgency:</strong> Prominent countdown timer ticking down to the presale start.</li>
            <li><strong>Trust:</strong> Social proof blocks and clear analytics tracking.</li>
          </ul>

          {/* Social Proof / Metrics Section */}
          <div className="not-prose my-12 p-8 bg-gradient-to-br from-surface to-pink-500/5 rounded-3xl border border-white/10 relative overflow-hidden group shadow-lg">
            <div className="absolute inset-0 bg-surface opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
            <h3 className="font-display text-2xl font-bold text-text-main mb-8 text-center relative z-10">Community Impact</h3>
            
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-10 text-center relative z-10">
              <div className="p-4 rounded-xl bg-surface border border-white/10 hover:border-pink-300 transition-colors shadow-sm">
                <div className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-pink-500 to-purple-500 mb-2">25K+</div>
                <div className="text-xs font-bold text-text-muted uppercase tracking-widest">Telegram</div>
              </div>
              <div className="p-4 rounded-xl bg-surface border border-white/10 hover:border-cyan-300 transition-colors shadow-sm">
                <div className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-cyan-500 to-blue-500 mb-2">15K+</div>
                <div className="text-xs font-bold text-text-muted uppercase tracking-widest">Holders</div>
              </div>
               <div className="p-4 rounded-xl bg-surface border border-white/10 hover:border-green-300 transition-colors shadow-sm">
                <div className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-green-500 to-emerald-500 mb-2">$5M</div>
                <div className="text-xs font-bold text-text-muted uppercase tracking-widest">Volume</div>
              </div>
              <div className="p-4 rounded-xl bg-surface border border-white/10 hover:border-yellow-300 transition-colors shadow-sm">
                <div className="text-3xl font-bold text-text-main mb-2">Top 1</div>
                <div className="text-xs font-bold text-text-muted uppercase tracking-widest">Trending</div>
              </div>
            </div>

            <div className="text-center relative z-10 pt-6 border-t border-white/10">
              <p className="text-text-muted text-xs font-bold uppercase tracking-widest mb-6">Launch Partners & Listings</p>
              <div className="flex flex-wrap justify-center gap-6 md:gap-12 opacity-60 hover:opacity-100 transition-opacity">
                 {['PancakeSwap', 'CoinGecko', 'Dextools'].map(partner => (
                    <span key={partner} className="font-display font-bold text-xl text-text-main">{partner}</span>
                 ))}
              </div>
            </div>
          </div>

          <h2>Result</h2>
          <p>The site achieved a <strong>34% visitor-to-whitelist conversion rate</strong>, significantly higher than the industry average of 12%. The viral mechanics (click-to-tweet and referral links) drove 40% of the total traffic.</p>
        </div>

        <div className="mt-16 text-center pt-10 border-t border-white/10">
          <Link to="/projects" className="inline-flex items-center text-pink-600 hover:text-pink-400 font-bold transition-colors">
            <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path></svg>
            Back to Projects
          </Link>
        </div>
      </div>
    </div>
  );
};

export default MemeCoinSite;