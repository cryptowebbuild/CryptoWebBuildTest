import React from 'react';
import { Link } from 'react-router-dom';
import SEO from '../../components/SEO';

const ShopFast: React.FC = () => {
  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Article",
    "headline": "Case Study: ShopFast - High Performance Static E-commerce",
    "image": "https://cryptowebbuild.com/project-ecommerce.jpg",
    "author": {
      "@type": "Organization",
      "name": "CryptoWebBuild"
    },
    "description": "Building an ultra-fast e-commerce store with sub-1s load times using static architecture and Stripe integration."
  };

  return (
    <div className="container mx-auto px-6 pt-32 pb-20">
      <SEO 
        title="Case Study: ShopFast - High Performance Static E-commerce"
        description="Building an ultra-fast e-commerce store with sub-1s load times using static architecture and Stripe integration."
      />
      <script type="application/ld+json">
        {JSON.stringify(jsonLd)}
      </script>
      <div className="max-w-4xl mx-auto animate-slide-up">
        <div className="inline-block px-3 py-1 mb-6 rounded-full bg-cyan-100 dark:bg-cyan-900/30 border border-cyan-200 dark:border-cyan-800 text-cyan-600 dark:text-cyan-300 text-xs font-bold uppercase tracking-wider shadow-sm">
          Case Study
        </div>
        <h1 className="font-display text-4xl md:text-5xl lg:text-6xl font-bold text-text-main mb-8 leading-tight">
          ShopFast — <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-500 to-blue-500">Lightweight E-commerce</span>
        </h1>
        
        <div className="rounded-3xl overflow-hidden shadow-2xl border border-slate-200 dark:border-slate-800 mb-12">
            <img src="/project-ecommerce.jpg" alt="ShopFast E-commerce UI" className="w-full h-auto object-cover" />
        </div>

        <div className="grid md:grid-cols-3 gap-6 mb-16">
          <div className="glass-panel p-6 rounded-2xl bg-surface border-t border-cyan-500/20">
            <h3 className="text-text-muted text-xs font-bold uppercase tracking-widest mb-2">Stack</h3>
            <p className="text-text-main font-bold text-lg">Static, Stripe JS</p>
          </div>
          <div className="glass-panel p-6 rounded-2xl bg-surface border-t border-cyan-500/20">
            <h3 className="text-text-muted text-xs font-bold uppercase tracking-widest mb-2">Focus</h3>
            <p className="text-text-main font-bold text-lg">Speed, SEO</p>
          </div>
          <div className="glass-panel p-6 rounded-2xl bg-surface border-t border-cyan-500/20">
            <h3 className="text-text-muted text-xs font-bold uppercase tracking-widest mb-2">Result</h3>
            <p className="text-green-500 font-bold text-lg">&lt; 1s Load Time</p>
          </div>
        </div>

        <div className="prose prose-lg prose-slate dark:prose-invert max-w-none">
          <h2>The Challenge</h2>
          <p>Traditional e-commerce platforms (like WooCommerce or Magento) were too slow and bloated for this client, causing high bounce rates on mobile devices. They needed a solution that was instant-loading globally.</p>

          <h2>The Solution</h2>
          <p>We implemented a headless static storefront. Key architectural decisions included:</p>
          <ul>
            <li><strong>Pre-rendered Product Pages:</strong> All product data is baked into HTML at build time for instant delivery.</li>
            <li><strong>Client-Side Cart:</strong> A lightweight JavaScript cart that persists state locally without server round-trips.</li>
            <li><strong>Stripe Checkout:</strong> Offloading PCI compliance and secure payments to Stripe's hosted checkout page.</li>
          </ul>

          <h2>The Outcome</h2>
          <p>The new site achieves a perfect 100/100 Performance score on Google PageSpeed Insights. Checkout abandonment dropped by 38%, directly attributing to the faster, friction-free experience.</p>
        </div>

        <div className="mt-16 text-center pt-10 border-t border-white/10">
          <Link to="/projects" className="inline-flex items-center text-cyan-600 hover:text-cyan-400 font-bold transition-colors">
            <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path></svg>
            Back to Projects
          </Link>
        </div>
      </div>
    </div>
  );
};

export default ShopFast;