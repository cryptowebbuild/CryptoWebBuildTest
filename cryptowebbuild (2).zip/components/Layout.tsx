import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';

interface LayoutProps {
  children?: React.ReactNode;
}

// Data extracted outside component to avoid recreation
const socialLinks = [
  { 
    label: 'X (Twitter)', 
    href: 'https://x.com/CryptowebbuildX', 
    d: "M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"
  },
  { 
    label: 'Telegram', 
    href: 'https://t.me/CryptoWebBuild', 
    d: "M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm4.64 6.8c-.15 1.58-.8 5.42-1.13 7.19-.14.75-.42 1-.68 1.03-.58.05-1.02-.38-1.58-.75-.88-.58-1.48-1.02-2.4-1.62-1.06-.69-.37-1.07.23-1.68.16-.16 2.87-2.63 2.92-2.85.01-.03.01-.14-.06-.2-.06-.05-.16-.04-.23-.02-.1.02-1.72 1.1-4.86 3.22-.46.32-.88.47-1.25.46-.4-.01-1.18-.23-1.75-.38-.7-.18-1.26-.28-1.21-.6.03-.16.24-.32.65-.49 2.56-1.11 4.27-1.84 5.12-2.2 2.43-1.01 2.93-1.19 3.26-1.19.07 0 .23.02.33.09.09.08.12.19.13.29v.04z"
  },
  { 
    label: 'Facebook', 
    href: 'https://www.facebook.com/CryptoWebBuild', 
    d: "M9.101 23.691v-7.98H6.627v-3.667h2.474v-1.58c0-4.085 1.848-5.978 5.858-5.978.401 0 .955.042 1.468.103a8.68 8.68 0 0 1 1.141.195v3.325a8.623 8.623 0 0 0-.653-.036c-2.648 0-2.928 1.67-2.928 3.403v1.575h2.713l-.502 3.66h-2.215v7.98H9.101Z"
  },
  { 
    label: 'GitHub', 
    href: 'https://github.com/cryptowebbuild', 
    d: "M12 2C6.477 2 2 6.484 2 12.017c0 4.425 2.865 8.18 6.839 9.504.5.092.682-.217.682-.483 0-.237-.008-.868-.013-1.703-2.782.605-3.369-1.343-3.369-1.343-.454-1.158-1.11-1.466-1.11-1.466-.908-.62.069-.608.069-.608 1.003.07 1.531 1.032 1.531 1.032.892 1.53 2.341 1.088 2.91.832.092-.647.35-1.088.636-1.338-2.22-.253-4.555-1.113-4.555-4.951 0-1.093.39-1.988 1.029-2.688-.103-.253-.446-1.272.098-2.65 0 0 .84-.27 2.75 1.026A9.607 9.607 0 0 1 12 6.82c.85.004 1.705.115 2.504.337 1.909-1.296 2.747-1.027 2.747-1.027.546 1.379.202 2.398.1 2.651.64.7 1.028 1.595 1.028 2.688 0 3.848-2.339 4.695-4.566 4.943.359.309.678.92.678 1.855 0 1.338-.012 2.419-.012 2.747 0 .268.18.58.688.482A10.019 10.019 0 0 0 22 12.017C22 6.484 17.522 2 12 2Z",
    fillRule: "evenodd"
  }
];

const Layout: React.FC<LayoutProps> = ({ children }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [theme, setTheme] = useState<'light' | 'dark'>('light');
  const location = useLocation();

  useEffect(() => {
    // Check local storage or system preference
    const storedTheme = localStorage.getItem('theme') as 'light' | 'dark' | null;
    const systemPrefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    
    if (storedTheme) {
      setTheme(storedTheme);
    } else if (systemPrefersDark) {
      setTheme('dark');
    }
  }, []);

  useEffect(() => {
    // Apply theme class to html
    const root = document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
    localStorage.setItem('theme', theme);
  }, [theme]);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 10);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Close menu on route change & prevent body scroll when menu open
  useEffect(() => {
    setIsMenuOpen(false);
    window.scrollTo(0,0);
  }, [location.pathname]);
  
  useEffect(() => {
    if (isMenuOpen) {
        document.body.style.overflow = 'hidden';
    } else {
        document.body.style.overflow = 'unset';
    }
    // Cleanup to ensure scroll is restored if component unmounts
    return () => {
        document.body.style.overflow = 'unset';
    };
  }, [isMenuOpen]);

  const toggleTheme = () => {
    setTheme(prev => prev === 'light' ? 'dark' : 'light');
  };

  const navLinks = [
    { path: '/', label: 'Home' },
    { path: '/services', label: 'Services' },
    { path: '/projects', label: 'Work' },
    { path: '/videos', label: 'Videos' },
    { path: '/blog', label: 'Blog' },
    { path: '/about', label: 'About' },
  ];

  // Helper for active link styles
  const getLinkClass = (path: string, isMobile = false) => {
    const isActive = location.pathname === path || (path !== '/' && location.pathname.startsWith(path));
    
    if (isMobile) {
      return `text-4xl font-display font-bold transition-all duration-300 ${
        isActive 
          ? 'text-transparent bg-clip-text bg-gradient-to-r from-purple-600 to-cyan-600' 
          : 'text-text-muted hover:text-text-main'
      }`;
    }

    return `relative px-4 py-2 text-sm font-medium transition-all duration-300 rounded-full ${
      isActive 
        ? 'text-purple-600 bg-purple-50 dark:bg-purple-900/20 dark:text-purple-300 shadow-sm border border-purple-100 dark:border-purple-800' 
        : 'text-text-muted hover:text-text-main hover:bg-surface-highlight'
    }`;
  };

  return (
    <div className="min-h-screen relative font-sans text-text-main overflow-x-hidden flex flex-col bg-void selection:bg-purple-500/30 selection:text-purple-200">
      
      {/* --- Cosmic Background --- */}
      <div className="fixed inset-0 z-0 bg-void pointer-events-none overflow-hidden transition-colors duration-500">
        {/* Gradients */}
        <div className="absolute top-0 right-0 w-[50vw] h-[50vw] bg-purple-500/10 dark:bg-purple-900/20 rounded-full blur-[120px] opacity-70 animate-blob" />
        <div className="absolute bottom-0 left-0 w-[50vw] h-[50vw] bg-blue-500/10 dark:bg-blue-900/20 rounded-full blur-[120px] opacity-70 animate-blob animation-delay-2000" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[40vw] h-[40vw] bg-cyan-500/10 dark:bg-cyan-900/20 rounded-full blur-[100px] opacity-50 animate-blob animation-delay-4000" />
        
        {/* Wireframe Shapes */}
        <svg className="absolute top-[15%] left-[5%] w-32 h-32 text-purple-500/10 dark:text-purple-400/10 animate-float" viewBox="0 0 100 100" fill="none" stroke="currentColor" strokeWidth="1">
            <path d="M50 5 L95 27.5 L95 72.5 L50 95 L5 72.5 L5 27.5 Z" />
        </svg>

        <svg className="absolute top-[25%] right-[10%] w-48 h-48 text-cyan-500/10 dark:text-cyan-400/10 animate-spin-slow" viewBox="0 0 100 100" fill="none" stroke="currentColor" strokeWidth="0.5">
            <circle cx="50" cy="50" r="45" strokeDasharray="5,5" />
            <rect x="25" y="25" width="50" height="50" transform="rotate(45 50 50)" />
        </svg>

        <svg className="absolute bottom-[20%] left-[10%] w-40 h-40 text-blue-500/10 dark:text-blue-400/10 animate-float" style={{ animationDelay: '1s' }} viewBox="0 0 100 100" fill="none" stroke="currentColor" strokeWidth="1">
            <path d="M10 50 Q 25 25 50 10 Q 75 25 90 50 Q 75 75 50 90 Q 25 75 10 50 Z" />
        </svg>
        
        {/* Subtle Grid */}
        <div className="absolute inset-0 opacity-[0.4] dark:opacity-[0.2]" 
          style={{
            backgroundImage: `linear-gradient(var(--grid-color) 1px, transparent 1px), linear-gradient(to right, var(--grid-color) 1px, transparent 1px)`,
            backgroundSize: '48px 48px'
          }}
        ></div>
        
        {/* Noise Texture */}
        <div className="absolute inset-0 opacity-[0.03] dark:opacity-[0.05] bg-[url('https://grainy-gradients.vercel.app/noise.svg')]"></div>
      </div>

      {/* --- Floating Navbar --- */}
      <header 
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ease-in-out ${
          scrolled ? 'py-3' : 'py-5'
        }`}
      >
        <div className="container mx-auto px-4 md:px-6">
          <nav 
            className={`mx-auto max-w-7xl flex items-center justify-between px-5 py-2.5 rounded-full transition-all duration-300 ${
              scrolled 
                ? 'glass-panel shadow-lg' 
                : 'bg-surface/40 backdrop-blur-md border border-white/10 shadow-sm'
            }`}
          >
            {/* Logo */}
            <Link to="/" className="relative z-50 flex items-center gap-3 group">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-600 to-blue-600 flex items-center justify-center shadow-lg shadow-purple-500/20 group-hover:scale-110 transition-transform duration-300 border border-white/20">
                <span className="font-display font-bold text-white text-lg">C</span>
              </div>
              <span className="font-display font-bold text-xl tracking-tight text-text-main group-hover:text-purple-600 dark:group-hover:text-purple-400 transition-colors">
                Crypto<span className="text-text-muted font-normal">WebBuild</span>
              </span>
            </Link>

            {/* Desktop Navigation */}
            <div className="hidden lg:flex items-center gap-1.5 p-1 bg-surface/50 rounded-full border border-white/10 dark:border-white/5 shadow-sm">
              {navLinks.map((link) => (
                <Link key={link.path} to={link.path} className={getLinkClass(link.path)}>
                   {link.label}
                </Link>
              ))}
            </div>

            {/* Right Side Actions */}
            <div className="flex items-center gap-3">
              
              {/* Theme Toggle */}
              <button 
                onClick={toggleTheme}
                className="p-2.5 rounded-full text-text-muted hover:text-text-main hover:bg-surface-highlight transition-all border border-transparent hover:border-white/10 active:scale-95"
                aria-label="Toggle Dark Mode"
              >
                {theme === 'dark' ? (
                  <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z" />
                  </svg>
                ) : (
                  <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z" />
                  </svg>
                )}
              </button>

              {/* Desktop CTA */}
              <div className="hidden md:block">
                <Link 
                  to="/contact" 
                  className="relative inline-flex items-center justify-center px-6 py-2.5 overflow-hidden font-bold text-white transition-all duration-300 bg-gradient-to-r from-purple-600 to-cyan-600 rounded-full group hover:scale-105 hover:shadow-lg hover:shadow-purple-500/30 focus:outline-none ring-offset-2 focus:ring-2 ring-purple-500 dark:ring-offset-slate-900"
                >
                  <span className="absolute inset-0 w-full h-full bg-gradient-to-br from-purple-500 via-purple-600 to-cyan-500 opacity-0 group-hover:opacity-100 transition-opacity duration-300 ease-out"></span>
                  <span className="relative flex items-center gap-2">
                    Hire Me
                    <svg className="w-4 h-4 transition-transform group-hover:translate-x-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M14 5l7 7m0 0l-7 7m7-7H3"></path></svg>
                  </span>
                </Link>
              </div>

              {/* Mobile Hamburger */}
              <button 
                onClick={() => setIsMenuOpen(!isMenuOpen)}
                className="lg:hidden relative z-50 p-2.5 rounded-full hover:bg-surface-highlight text-text-main focus:outline-none transition-colors border border-transparent hover:border-white/10"
                aria-label="Toggle Menu"
              >
                <div className="w-6 h-5 flex flex-col justify-between overflow-visible">
                  <span className={`h-0.5 bg-current w-full transform transition-all duration-300 rounded-full origin-left ${isMenuOpen ? 'rotate-45 translate-x-1' : ''}`} />
                  <span className={`h-0.5 bg-current w-full transform transition-all duration-300 rounded-full ${isMenuOpen ? 'opacity-0 scale-0' : 'opacity-100 scale-100'}`} />
                  <span className={`h-0.5 bg-current w-full transform transition-all duration-300 rounded-full origin-left ${isMenuOpen ? '-rotate-45 translate-x-1' : ''}`} />
                </div>
              </button>
            </div>

          </nav>
        </div>
      </header>

      {/* --- Full Screen Mobile Menu --- */}
      <div 
        className={`fixed inset-0 z-40 bg-surface/95 backdrop-blur-2xl transition-all duration-500 flex flex-col items-center justify-center ${
          isMenuOpen ? 'opacity-100 pointer-events-auto translate-y-0' : 'opacity-0 pointer-events-none -translate-y-4'
        }`}
      >
        {/* Background Decor */}
        <div className="absolute top-0 right-0 w-64 h-64 bg-purple-500/10 rounded-full blur-[80px]" />
        <div className="absolute bottom-0 left-0 w-64 h-64 bg-cyan-500/10 rounded-full blur-[80px]" />

        <div className="relative z-10 flex flex-col items-center gap-8 w-full max-w-sm px-6 text-center">
          {navLinks.map((link, idx) => (
            <Link 
              key={link.path}
              to={link.path}
              className={getLinkClass(link.path, true)}
              style={{ transitionDelay: isMenuOpen ? `${100 + idx * 50}ms` : '0ms' }}
              onClick={() => setIsMenuOpen(false)}
            >
              {link.label}
            </Link>
          ))}
          
          <div className="w-12 h-1 bg-surface-highlight rounded-full my-4" />
          
          <Link 
            to="/contact"
            onClick={() => setIsMenuOpen(false)}
            className="w-full py-4 bg-gradient-to-r from-purple-600 to-cyan-600 text-white font-bold text-lg rounded-2xl shadow-xl shadow-purple-500/20 active:scale-95 transition-transform"
          >
            Start a Project
          </Link>
          
          <div className="flex gap-4 mt-8">
             {socialLinks.map((social) => (
                <a 
                  key={social.label} 
                  href={social.href} 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className="p-2 text-text-muted hover:text-text-main hover:bg-surface-highlight rounded-full transition-colors"
                  aria-label={social.label}
                >
                  <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                     <path 
                       d={social.d} 
                       fillRule={social.fillRule ? (social.fillRule as any) : undefined} 
                       clipRule={social.fillRule ? (social.fillRule as any) : undefined} 
                     />
                  </svg>
                </a>
             ))}
          </div>
        </div>
      </div>

      {/* --- Main Content --- */}
      <main className="relative z-10 flex-grow pt-24">
        {children}
      </main>

      {/* --- Cosmic Footer (Light) --- */}
      <footer className="relative z-10 mt-32 bg-surface border-t border-white/10 shadow-[0_-10px_40px_rgba(0,0,0,0.02)]">
        <div className="absolute inset-0 bg-gradient-to-t from-purple-500/5 to-transparent pointer-events-none"></div>
        
        <div className="container mx-auto px-6 py-16 md:py-24 relative z-10">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-12 lg:gap-16">
            
            {/* Brand Column */}
            <div className="lg:col-span-4 space-y-6">
              <Link to="/" className="inline-flex items-center gap-2 group">
                 <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-purple-600 to-blue-600 flex items-center justify-center text-white font-bold font-display shadow-lg shadow-purple-500/20">C</div>
                 <span className="font-display font-bold text-2xl text-text-main tracking-tight group-hover:text-purple-600 transition-colors">CryptoWebBuild</span>
              </Link>
              <p className="text-text-muted leading-relaxed max-w-sm text-base">
                Forging the decentralized web with pixel-perfect precision. 
                Specializing in high-performance Web3 interfaces, token launches, 
                and conversion-driven digital experiences.
              </p>
              <div className="flex gap-3">
                {/* Social Icons - Clean Circle Style */}
                {socialLinks.map((social) => (
                  <a 
                    key={social.label} 
                    href={social.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label={social.label}
                    className="w-10 h-10 rounded-full bg-surface-highlight border border-white/10 text-text-muted flex items-center justify-center transition-all duration-300 hover:-translate-y-1 hover:bg-purple-600 hover:text-white hover:border-purple-600 group"
                  >
                    <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24">
                      <path 
                       d={social.d} 
                       fillRule={social.fillRule ? (social.fillRule as any) : undefined} 
                       clipRule={social.fillRule ? (social.fillRule as any) : undefined} 
                     />
                    </svg>
                  </a>
                ))}
              </div>
            </div>

            {/* Navigation Links - Organized */}
            <div className="lg:col-span-2">
              <h4 className="font-display font-bold text-text-main mb-6 text-sm uppercase tracking-wider">Company</h4>
              <ul className="space-y-4 text-text-muted font-medium">
                <li><Link to="/about" className="hover:text-purple-600 transition-colors block">About Me</Link></li>
                <li><Link to="/services" className="hover:text-purple-600 transition-colors block">Services</Link></li>
                <li><Link to="/projects" className="hover:text-purple-600 transition-colors block">Case Studies</Link></li>
                <li><Link to="/contact" className="hover:text-purple-600 transition-colors block">Contact</Link></li>
              </ul>
            </div>

            <div className="lg:col-span-2">
              <h4 className="font-display font-bold text-text-main mb-6 text-sm uppercase tracking-wider">Resources</h4>
              <ul className="space-y-4 text-text-muted font-medium">
                <li><Link to="/blog" className="hover:text-cyan-600 transition-colors block">Blog</Link></li>
                <li><Link to="/videos" className="hover:text-cyan-600 transition-colors block">Tutorials</Link></li>
                <li><Link to="/faq" className="hover:text-cyan-600 transition-colors block">FAQ</Link></li>
                <li><Link to="/sitemap.xml" className="hover:text-cyan-600 transition-colors block">Sitemap</Link></li>
              </ul>
            </div>

            {/* CTA Column */}
            <div className="lg:col-span-4">
              <h4 className="font-display font-bold text-text-main mb-6 text-sm uppercase tracking-wider">Start Building</h4>
              <div className="p-6 rounded-2xl bg-surface-highlight/50 border border-white/10 hover:border-purple-500/30 transition-colors">
                <p className="text-text-muted mb-4 text-sm font-medium">Ready to build the future? Let's discuss your project.</p>
                <a 
                  href="https://t.me/CryptoWebBuild" 
                  target="_blank"
                  rel="noopener noreferrer"
                  className="group flex w-full items-center justify-center gap-2 py-3.5 bg-gradient-to-r from-purple-600 to-blue-600 text-white font-bold rounded-xl hover:shadow-lg hover:shadow-purple-500/20 transition-all"
                >
                  <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm4.64 6.8c-.15 1.58-.8 5.42-1.13 7.19-.14.75-.42 1-.68 1.03-.58.05-1.02-.38-1.58-.75-.88-.58-1.48-1.02-2.4-1.62-1.06-.69-.37-1.07.23-1.68.16-.16 2.87-2.63 2.92-2.85.01-.03.01-.14-.06-.2-.06-.05-.16-.04-.23-.02-.1.02-1.72 1.1-4.86 3.22-.46.32-.88.47-1.25.46-.4-.01-1.18-.23-1.75-.38-.7-.18-1.26-.28-1.21-.6.03-.16.24-.32.65-.49 2.56-1.11 4.27-1.84 5.12-2.2 2.43-1.01 2.93-1.19 3.26-1.19.07 0 .23.02.33.09.09.08.12.19.13.29v.04z"/></svg>
                  <span>Chat on Telegram</span>
                </a>
                <div className="mt-4 flex items-center justify-center gap-2 text-xs text-text-muted">
                   <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse shadow-[0_0_8px_rgba(34,197,94,0.4)]"></span>
                   <span>Usually replies within 1 hour</span>
                </div>
              </div>
            </div>

          </div>

          <div className="mt-20 pt-8 border-t border-white/10 flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-text-muted">
            <p>&copy; {new Date().getFullYear()} CryptoWebBuild. All rights reserved.</p>
            <div className="flex gap-8">
              <Link to="/privacy" className="hover:text-purple-600 transition-colors">Privacy Policy</Link>
              <Link to="/terms" className="hover:text-purple-600 transition-colors">Terms of Service</Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Layout;