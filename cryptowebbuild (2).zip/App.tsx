import React, { useEffect, Suspense, lazy } from 'react';
import { HashRouter, Routes, Route, useLocation } from 'react-router-dom';
import Layout from './components/Layout';
import Home from './pages/Home'; // Eager load Home for immediate LCP

// Lazy load pages to defer non-critical JavaScript
const About = lazy(() => import('./pages/About'));
const Services = lazy(() => import('./pages/Services'));
const Projects = lazy(() => import('./pages/Projects'));
const Videos = lazy(() => import('./pages/Videos'));
const Blog = lazy(() => import('./pages/Blog'));
const Contact = lazy(() => import('./pages/Contact'));
const ThankYou = lazy(() => import('./pages/ThankYou'));

// Blog Posts
const BestDeveloper = lazy(() => import('./pages/blog/BestDeveloper'));
const CryptoProject = lazy(() => import('./pages/blog/CryptoProject'));
const MemeCoinFeatures = lazy(() => import('./pages/blog/MemeCoinFeatures'));
const CryptoCost = lazy(() => import('./pages/blog/CryptoCost'));
const StaticVsDynamic = lazy(() => import('./pages/blog/StaticVsDynamic'));
const WebsiteBuilderVsDeveloper = lazy(() => import('./pages/blog/WebsiteBuilderVsDeveloper'));

// Case Studies
const TokenLaunch = lazy(() => import('./pages/cases/TokenLaunch'));
const MemeCoinSite = lazy(() => import('./pages/cases/MemeCoinSite'));
const ShopFast = lazy(() => import('./pages/cases/ShopFast'));

// Legal & Support Pages
const FAQ = lazy(() => import('./pages/FAQ'));
const Privacy = lazy(() => import('./pages/Privacy'));
const Terms = lazy(() => import('./pages/Terms'));

// Scroll to top helper
const ScrollToTop = () => {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);
  return null;
};

// Cosmic Loading Spinner
const PageLoader = () => (
  <div className="min-h-screen flex items-center justify-center bg-void">
    <div className="relative w-20 h-20">
      <div className="absolute inset-0 border-t-4 border-purple-500 border-solid rounded-full animate-spin"></div>
      <div className="absolute inset-3 border-t-4 border-cyan-500 border-solid rounded-full animate-spin-slow"></div>
    </div>
  </div>
);

const App: React.FC = () => {
  return (
    <HashRouter>
      <ScrollToTop />
      <Layout>
        <Suspense fallback={<PageLoader />}>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/about" element={<About />} />
            <Route path="/services" element={<Services />} />
            <Route path="/projects" element={<Projects />} />
            <Route path="/videos" element={<Videos />} />
            <Route path="/blog" element={<Blog />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="/thank-you" element={<ThankYou />} />
            
            {/* Legal & Support */}
            <Route path="/faq" element={<FAQ />} />
            <Route path="/privacy" element={<Privacy />} />
            <Route path="/terms" element={<Terms />} />
            
            {/* Blog Routes */}
            <Route path="/best-website-developer" element={<BestDeveloper />} />
            <Route path="/crypto-project-website" element={<CryptoProject />} />
            <Route path="/meme-coin-website-features" element={<MemeCoinFeatures />} />
            <Route path="/crypto-website-cost" element={<CryptoCost />} />
            <Route path="/static-vs-dynamic-website" element={<StaticVsDynamic />} />
            <Route path="/website-builder-vs-developer" element={<WebsiteBuilderVsDeveloper />} />

            {/* Project Case Studies */}
            <Route path="/tokenlaunch" element={<TokenLaunch />} />
            <Route path="/memecoinsite" element={<MemeCoinSite />} />
            <Route path="/shopfast" element={<ShopFast />} />
          </Routes>
        </Suspense>
      </Layout>
    </HashRouter>
  );
};

export default App;